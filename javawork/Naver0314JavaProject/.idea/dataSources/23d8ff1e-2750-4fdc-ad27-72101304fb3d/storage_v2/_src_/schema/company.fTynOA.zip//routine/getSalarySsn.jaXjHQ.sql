create
    definer = root@localhost procedure getSalarySsn(IN sn char(9), OUT inc_sal int)
begin
	declare sal int;
	select salary into sal from employee where ssn = sn;
	set inc_sal = sal * 1.1 ;

end;

