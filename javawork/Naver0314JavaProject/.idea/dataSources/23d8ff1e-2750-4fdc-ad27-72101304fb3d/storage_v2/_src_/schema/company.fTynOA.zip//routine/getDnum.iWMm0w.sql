create
    definer = root@localhost procedure getDnum(IN pid int, OUT dn int)
begin 
	select dnum into dn from project where pnumber = pid;
end;

