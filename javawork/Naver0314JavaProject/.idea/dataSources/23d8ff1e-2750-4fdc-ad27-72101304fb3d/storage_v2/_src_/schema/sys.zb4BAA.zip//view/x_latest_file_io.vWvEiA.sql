create definer = `mariadb.sys`@localhost view x$latest_file_io as
select if(`information_schema`.`processlist`.`ID` is null,
          concat(substring_index(`performance_schema`.`threads`.`NAME`, '/', -1), ':',
                 `performance_schema`.`events_waits_history_long`.`THREAD_ID`),
          concat(`information_schema`.`processlist`.`USER`, '@', `information_schema`.`processlist`.`HOST`, ':',
                 `information_schema`.`processlist`.`ID`))                AS `thread`,
       `performance_schema`.`events_waits_history_long`.`OBJECT_NAME`     AS `file`,
       `performance_schema`.`events_waits_history_long`.`TIMER_WAIT`      AS `latency`,
       `performance_schema`.`events_waits_history_long`.`OPERATION`       AS `operation`,
       `performance_schema`.`events_waits_history_long`.`NUMBER_OF_BYTES` AS `requested`
from ((`performance_schema`.`events_waits_history_long` join `performance_schema`.`threads`
       on (`performance_schema`.`events_waits_history_long`.`THREAD_ID` =
           `performance_schema`.`threads`.`THREAD_ID`)) left join `information_schema`.`processlist`
      on (`performance_schema`.`threads`.`PROCESSLIST_ID` = `information_schema`.`processlist`.`ID`))
where `performance_schema`.`events_waits_history_long`.`OBJECT_NAME` is not null
  and `performance_schema`.`events_waits_history_long`.`EVENT_NAME` like 'wait/io/file/%'
order by `performance_schema`.`events_waits_history_long`.`TIMER_START`;

-- comment on column x$latest_file_io.file not supported: File name for file I/O objects, table name for table I/O objects, the socket's IP:PORT value for a socket object or NULL for a synchronization object.

-- comment on column x$latest_file_io.latency not supported: Value in picoseconds of the event's duration or NULL if the event has not ended or timing is not collected.

-- comment on column x$latest_file_io.operation not supported: Operation type, for example read, write or lock

-- comment on column x$latest_file_io.requested not supported: Number of bytes that the operation read or wrote, or NULL for table I/O waits.

